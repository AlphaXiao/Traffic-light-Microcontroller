package luckyhotel.test;

import luckyhotel.util.DbUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class DbTest {

	public static void main(String[] args) throws Exception {
		// 1. install mysql-server database on local.
		// 2. modify DbUtil host, user（mysql username），password（mysql password）
		// 3. run DbTest#main
		try (Connection con = DbUtil.getConnection(true)) {
			try (PreparedStatement ps = con.prepareStatement("create database if not exists " + DbUtil.getDatabase() + " default character set utf8mb4")) {
				ps.execute();
			}
			con.setCatalog(DbUtil.getDatabase());
			StringBuilder customerSql = new StringBuilder("drop table if exists tb_user;");
			customerSql.append(" create table if not exists tb_user (")//
					.append(" userID varchar(100) not null primary key,")//
					.append(" email varchar(100) not null,")//
					.append(" password varchar(100) not null,")//
					.append(" role int(11) not null")//
					.append(" ) engine=innodb default charset=utf8mb4");
			try (PreparedStatement ps = con.prepareStatement(customerSql.toString())) {
				ps.execute();
			}

			StringBuilder adminSql = new StringBuilder();
			adminSql.append("insert into tb_user values('1', 'admin@admin.com', '123', 0)");
			try (PreparedStatement ps = con.prepareStatement(adminSql.toString())) {
				ps.execute();
			}

			StringBuilder roomSql = new StringBuilder("drop table if exists tb_room;");
			roomSql.append(" create table if not exists tb_room (")//
					.append(" roomID varchar(100) not null primary key,")//
					.append(" description varchar(100) not null,")//
					.append(" amountOfGuest int(11) not null,")//
					.append(" amountOfBed int(11) not null,")//
					.append(" price double not null,")//
					.append(" averageRating double not null")//
					.append(" ) engine=innodb default charset=utf8mb4");
			try (PreparedStatement ps = con.prepareStatement(roomSql.toString())) {
				ps.execute();
			}

			StringBuilder reviewSql = new StringBuilder("drop table if exists tb_review;");
			reviewSql.append(" create table if not exists tb_review (")//
					.append(" roomID varchar(100) not null,")//
					.append(" userID varchar(100) not null,")//
					.append(" comment varchar(11) not null,")//
					.append(" rating int(11) not null")//
					.append(" ) engine=innodb default charset=utf8mb4");
			try (PreparedStatement ps = con.prepareStatement(reviewSql.toString())) {
				ps.execute();
			}

			StringBuilder transactionSql = new StringBuilder("drop table if exists tb_transaction;");
			transactionSql.append(" create table if not exists tb_transaction (")//
					.append(" transactionID int(11) not null auto_increment primary key,")//
					.append(" dateBookingStart datetime not null,")//
					.append(" dateBookingEnd datetime not null,")//
					.append(" amountPaid double not null,")//
					.append(" roomPrice double not null,")//
					.append(" successful tinyint(1) not null,")//
					.append(" userID varchar(64) not null,")//
					.append(" roomID varchar(64) not null")//
					.append(" ) engine=innodb default charset=utf8mb4");
			try (PreparedStatement ps = con.prepareStatement(transactionSql.toString())) {
				ps.execute();
			}

		}

	}

}
