package luckyhotel.entity;

import java.util.Date;

public class Transaction {

	private Integer transactionID;
	private Date dateBookingStart;
	private Date dateBookingEnd;
	private Double amountPaid;
	private Double roomPrice;
	private Boolean successful;
	private String userID;
	private String roomID;

	public Integer getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(Integer transactionID) {
		this.transactionID = transactionID;
	}

	public Date getDateBookingStart() {
		return dateBookingStart;
	}

	public void setDateBookingStart(Date dateBookingStart) {
		this.dateBookingStart = dateBookingStart;
	}

	public Date getDateBookingEnd() {
		return dateBookingEnd;
	}

	public void setDateBookingEnd(Date dateBookingEnd) {
		this.dateBookingEnd = dateBookingEnd;
	}

	public Double getAmountPaid() {
		return amountPaid;
	}

	public void setAmountPaid(Double amountPaid) {
		this.amountPaid = amountPaid;
	}

	public Double getRoomPrice() {
		return roomPrice;
	}

	public void setRoomPrice(Double roomPrice) {
		this.roomPrice = roomPrice;
	}

	public Boolean getSuccessful() {
		return successful;
	}

	public void setSuccessful(Boolean successful) {
		this.successful = successful;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}
	
	public String getRoomID() {
		return roomID;
	}

	public void setRoomID(String roomID) {
		this.roomID = roomID;
	}

}
