package luckyhotel.entity;

import java.util.List;

public class Room {

	private String roomID;
	private String description;
	private Integer amountOfGuest;
	private Integer amountOfBed;
	private Double price;
	private Double averageRating;
	private List<Review> listOfReview;

	public String getRoomID() {
		return roomID;
	}

	public void setRoomID(String roomID) {
		this.roomID = roomID;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getAmountOfGuest() {
		return amountOfGuest;
	}

	public void setAmountOfGuest(Integer amountOfGuest) {
		this.amountOfGuest = amountOfGuest;
	}

	public Integer getAmountOfBed() {
		return amountOfBed;
	}

	public void setAmountOfBed(Integer amountOfBed) {
		this.amountOfBed = amountOfBed;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Double getAverageRating() {
		return averageRating;
	}

	public void setAverageRating(Double averageRating) {
		this.averageRating = averageRating;
	}

	public List<Review> getListOfReview() {
		return listOfReview;
	}

	public void setListOfReview(List<Review> listOfReview) {
		this.listOfReview = listOfReview;
	}

	@Override
	public String toString() {
		return "Room [roomID=" + roomID + ", description=" + description + ", amountOfGuest=" + amountOfGuest
				+ ", amountOfBed=" + amountOfBed + ", price=" + price + ", averageRating=" + averageRating
				+ ", listOfReview=" + listOfReview + "]";
	}

}
