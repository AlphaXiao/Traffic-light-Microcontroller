package luckyhotel.entity;

import java.util.Set;

public class RoomQuery {

    private Double minPrice;
    private Double maxPrice;
    private Double rating;
    private Integer amountOfGuest;
    private Integer amountOfBed;

    private String sortField;
    private String asc;

    private Set<String> notInRoomIDSet;

    public Double getMinPrice() {
        return minPrice;
    }

    public void setMinPrice(Double minPrice) {
        this.minPrice = minPrice;
    }

    public Double getMaxPrice() {
        return maxPrice;
    }

    public void setMaxPrice(Double maxPrice) {
        this.maxPrice = maxPrice;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public Integer getAmountOfGuest() {
        return amountOfGuest;
    }

    public void setAmountOfGuest(Integer amountOfGuest) {
        this.amountOfGuest = amountOfGuest;
    }

    public Integer getAmountOfBed() {
        return amountOfBed;
    }

    public void setAmountOfBed(Integer amountOfBed) {
        this.amountOfBed = amountOfBed;
    }

    public String getSortField() {
        return sortField;
    }

    public void setSortField(String sortField) {
        this.sortField = sortField;
    }

    public String getAsc() {
        return asc;
    }

    public void setAsc(String asc) {
        this.asc = asc;
    }

    public Set<String> getNotInRoomIDSet() {
        return notInRoomIDSet;
    }

    public void setNotInRoomIDSet(Set<String> notInRoomIDSet) {
        this.notInRoomIDSet = notInRoomIDSet;
    }
}
