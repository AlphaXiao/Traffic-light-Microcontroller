package luckyhotel.entity;

import java.util.List;

public class User {

	private String userID;
	private String email;
	private String password;
	private Integer role;
	private List<Room> listOfBookingRooms;
	private List<Transaction> listOfTransactionHistory;

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public Integer getRole() {
		return role;
	}

	public void setRole(Integer role) {
		this.role = role;
	}

	public List<Room> getListOfBookingRooms() {
		return listOfBookingRooms;
	}

	public void setListOfBookingRooms(List<Room> listOfBookingRooms) {
		this.listOfBookingRooms = listOfBookingRooms;
	}

	public List<Transaction> getListOfTransactionHistory() {
		return listOfTransactionHistory;
	}

	public void setListOfTransactionHistory(List<Transaction> listOfTransactionHistory) {
		this.listOfTransactionHistory = listOfTransactionHistory;
	}

	@Override
	public String toString() {
		return "User [userID=" + userID + ", email=" + email + ", password=" + password + ", role=" + role
				+ ", listOfBookingRooms=" + listOfBookingRooms + ", listOfTransactionHistory="
				+ listOfTransactionHistory + "]";
	}

}
