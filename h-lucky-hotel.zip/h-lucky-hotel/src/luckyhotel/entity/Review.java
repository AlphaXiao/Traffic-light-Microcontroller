package luckyhotel.entity;

public class Review {

	private String roomID;
	private String userID;
	private String comment;
	private Integer rating;

	public String getRoomID() {
		return roomID;
	}

	public void setRoomID(String roomID) {
		this.roomID = roomID;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	@Override
	public String toString() {
		return "Review [roomID=" + roomID + ", userID=" + userID + ", comment=" + comment + ", rating=" + rating + "]";
	}

}
