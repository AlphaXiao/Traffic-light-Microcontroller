package luckyhotel.exception;

public class ReviewOperationException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public ReviewOperationException(String message) {
        super(message);
    }

}
