package luckyhotel.exception;

public class UpdatePasswordException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public UpdatePasswordException(String message) {
        super(message);
    }

}
