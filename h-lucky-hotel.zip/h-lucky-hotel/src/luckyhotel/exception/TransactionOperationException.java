package luckyhotel.exception;

public class TransactionOperationException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public TransactionOperationException(String message) {
        super(message);
    }

}
