package luckyhotel.exception;

public class RoomOperationException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public RoomOperationException(String message) {
        super(message);
    }

}
