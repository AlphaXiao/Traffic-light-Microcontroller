package luckyhotel.util;

import java.util.Map;

public interface Callback {

    void call(Object o, Map<String, Object> params);

}
