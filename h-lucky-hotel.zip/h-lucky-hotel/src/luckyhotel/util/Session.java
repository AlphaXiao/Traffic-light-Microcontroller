package luckyhotel.util;

public class Session {

    public static final int ADMIN = 0;
    public static final int CUSTOMER = 1;

    private static String _userID;
    private static String _email;
    private static Integer _role;

    public static void setUser(String userID, String email, Integer role) {
        if (_userID == null) {
            _userID = userID;
            _email = email;
            _role = role;
        }
    }

    public static String getUserID() {
        return _userID;
    }

    public static String getEmail() {
        return _email;
    }

    public static Integer getRole() {
        return _role;
    }
}
