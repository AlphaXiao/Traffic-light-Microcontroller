package luckyhotel.util;

import java.sql.*;
import java.util.Date;
import java.util.*;

public class DbUtil {
	
	private static final String DATABASE = "lucky_hotel";
	
	public static String getDatabase() {
		return DATABASE;
	}

	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static Connection getConnection(boolean... nodatabase) {
		try {
			final String host = "127.0.0.1:3306";
			final String user = "root";
			final String password = "root";

			String db = (nodatabase != null && nodatabase.length > 0 && nodatabase[0]) ? "" : DATABASE;
			final String url = "jdbc:mysql://" + host + "/" + db
					+ "?useUnicode=true&characterEncoding=UTF-8&allowMultiQueries=true&serverTimezone=UTC";
			Connection connection = DriverManager.getConnection(url, user, password);
			return connection;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static List<Map<String, Object>> executeQuery(String sql, Object... params) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			ps = conn.prepareStatement(sql);
			if (params != null) {
				for (int i = 1; i <= params.length; i++) {
					ps.setObject(i, params[i - 1]);
				}
			}
			rs = ps.executeQuery();

			List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();
			while (rs.next()) {
				Map<String, Object> map = new LinkedHashMap<>();
				ResultSetMetaData rsmd = rs.getMetaData();
				int columnCount = rsmd.getColumnCount();
				for (int col = 1; col <= columnCount; col++) {
					String columnName = rsmd.getColumnName(col);
					Object object = rs.getObject(columnName);
					map.put(columnName, object);
				}
				resultList.add(map);
			}
			return resultList;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			close(rs, ps, conn);
		}
	}

	public static int executeUpdate(String sql, Object... params) {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = getConnection();
			ps = conn.prepareStatement(sql);
			if (params != null) {
				for (int i = 1; i <= params.length; i++) {
					ps.setObject(i, params[i - 1]);
				}
			}
			return ps.executeUpdate();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			close(ps, conn);
		}
	}

	private static void close(AutoCloseable... closeables) {
		if (closeables != null) {
			for (AutoCloseable close : closeables) {
				if (close != null) {
					try {
						close.close();
					} catch (Exception ignore) {
					}
				}
			}
		}
	}

	public static Date addDatetime(final Date date, final int calendarField, final int amount) {
		if (date == null) {
			throw new IllegalArgumentException("The date must not be null");
		}
		final Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(calendarField, amount);
		return c.getTime();
	}

}
