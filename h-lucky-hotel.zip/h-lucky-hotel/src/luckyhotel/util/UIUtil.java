package luckyhotel.util;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class UIUtil {

    public static void fillTable(JTable table, List<Object[]> list) {
        if (list == null) {
            return;
        }
        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
        tableModel.setRowCount(0);
        for (Object[] objects : list) {
            tableModel.addRow(objects);
        }
        table.invalidate();
    }

}
