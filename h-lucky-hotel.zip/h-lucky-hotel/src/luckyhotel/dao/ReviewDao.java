package luckyhotel.dao;

import luckyhotel.entity.Review;
import luckyhotel.util.DbUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ReviewDao {

    public List<Review> findByRoomID(String roomID) {
        List<Map<String, Object>> maps = DbUtil.executeQuery("select * from tb_review where roomID = ?", new Object[]{roomID});
        List<Review> reviews = new ArrayList<>();
        for (Map<String, Object> map : maps) {
            reviews.add(mapper(map));
        }
        return reviews;
    }

    public void save(Review review) {
        DbUtil.executeUpdate("insert into tb_review values(?,?,?,?)",
                new Object[]{review.getRoomID(), review.getUserID(), review.getComment(), review.getRating()});
    }

    private Review mapper(Map<String, Object> map) {
        Review review = new Review();
        review.setRoomID(map.get("roomID").toString());
        review.setUserID(map.get("userID").toString());
        review.setComment(map.get("comment") == null ? null : map.get("comment").toString());
        review.setRating(Integer.parseInt(map.get("rating").toString()));
        return review;
    }

}
