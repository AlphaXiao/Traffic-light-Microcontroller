package luckyhotel.dao;

import luckyhotel.entity.Room;
import luckyhotel.entity.RoomQuery;
import luckyhotel.util.DbUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class RoomDao {

    public List<Room> findAll() {
        List<Map<String, Object>> maps = DbUtil.executeQuery("select * from tb_room");
        List<Room> rooms = new ArrayList<>();
        for (Map<String, Object> map : maps) {
            Room room = mapper(map);
            rooms.add(room);
        }
        return rooms;
    }

    public Room findByRoomID(String roomID) {
        List<Map<String, Object>> maps = DbUtil.executeQuery("select * from tb_room where roomID = ?", new Object[]{roomID});
        if (maps.isEmpty()) {
            return null;
        }
        Map<String, Object> map = maps.get(0);
        return mapper(map);
    }

    public void save(Room room) {
        DbUtil.executeUpdate("insert into tb_room values(?,?,?,?,?,?)", new Object[]{
                room.getRoomID(), room.getDescription(), room.getAmountOfGuest(),
                room.getAmountOfBed(), room.getPrice(), room.getAverageRating()
        });
    }

    public void update(Room room) {
        DbUtil.executeUpdate("update tb_room " +
                        " set description = ?, amountOfGuest = ?, amountOfBed = ?, " +
                        " price = ?, averageRating = ? " +
                        " where roomID = ?",
                new Object[]{room.getDescription(), room.getAmountOfGuest(), room.getAmountOfBed(),
                        room.getPrice(), room.getAverageRating(), room.getRoomID()});
    }

    public void updateAverageRating(String roomID, double averageRating) {
        DbUtil.executeUpdate("update tb_room " +
                        " set averageRating = ? " +
                        " where roomID = ?",
                new Object[]{averageRating, roomID});
    }

    public List<Room> findByRoomQuery(RoomQuery roomQuery) {
        StringBuilder sql = new StringBuilder("select * from tb_room t where 1 = 1");
        List<Object> params = new ArrayList<>();
        if (!roomQuery.getNotInRoomIDSet().isEmpty()) {
            Set<String> notInRoomIDSet = roomQuery.getNotInRoomIDSet();
            sql.append(" and t.roomID not in (");
            int i = 0;
            for (String s : notInRoomIDSet) {
                if (i > 0) {
                    sql.append(",");
                }
                sql.append("?");
                params.add(s);
            }
            sql.append(")");
        }
        if (roomQuery.getAmountOfBed() != null) {
            sql.append(" and t.amountOfBed = ?");
            params.add(roomQuery.getAmountOfBed());
        }
        if (roomQuery.getAmountOfGuest() != null) {
            sql.append(" and t.amountOfGuest = ?");
            params.add(roomQuery.getAmountOfGuest());
        }
        if (roomQuery.getMinPrice() != null) {
            sql.append(" and t.price >= ?");
            params.add(roomQuery.getMinPrice());
        }
        if (roomQuery.getMaxPrice() != null) {
            sql.append(" and t.price <= ?");
            params.add(roomQuery.getMaxPrice());
        }
        if (roomQuery.getRating() != null) {
            sql.append(" and t.averageRating >= ?");
            params.add(roomQuery.getRating());
        }
        if (roomQuery.getSortField() != null) {
            sql.append(" order by ").append(roomQuery.getSortField());
            if (roomQuery.getAsc() != null) {
                sql.append(" ").append(roomQuery.getAsc());
            }
        }
        List<Map<String, Object>> maps = DbUtil.executeQuery(sql.toString(), params.toArray(new Object[0]));
        List<Room> list = new ArrayList<>();
        for (Map<String, Object> map : maps) {
            list.add(mapper(map));
        }
        return list;
    }

    private Room mapper(Map<String, Object> map) {
        Room room = new Room();
        room.setRoomID(map.get("roomID").toString());
        room.setAmountOfBed(Integer.parseInt(map.get("amountOfBed").toString()));
        room.setAmountOfGuest(Integer.parseInt(map.get("amountOfGuest").toString()));
        room.setAverageRating(Double.parseDouble(map.get("averageRating").toString()));
        room.setDescription(map.get("description").toString());
        room.setPrice(Double.parseDouble(map.get("price").toString()));
        return room;
    }

}
