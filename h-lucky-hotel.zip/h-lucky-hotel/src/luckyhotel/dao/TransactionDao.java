package luckyhotel.dao;

import luckyhotel.entity.Transaction;
import luckyhotel.util.DbUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class TransactionDao {

    public List<Transaction> findByUserID(String userID) {
        List<Map<String, Object>> maps = DbUtil.executeQuery("select * from tb_transaction where userID = ?", new Object[]{userID});
        List<Transaction> list = new ArrayList<>();
        for (Map<String, Object> map : maps) {
            list.add(mapper(map));
        }
        return list;
    }

    public List<Transaction> findByGtEndDate(Date end) {
        List<Map<String, Object>> maps = DbUtil.executeQuery("select * from tb_transaction where dateBookingEnd > ?",
                new Object[]{end});
        List<Transaction> list = new ArrayList<>();
        for (Map<String, Object> map : maps) {
            list.add(mapper(map));
        }
        return list;
    }

    public void save(Transaction t) {
        DbUtil.executeUpdate("insert into tb_transaction values(?,?,?,?,?,?,?,?)",
                new Object[]{t.getTransactionID(), t.getDateBookingStart(),
                        t.getDateBookingEnd(), t.getAmountPaid(),
                        t.getRoomPrice(), t.getSuccessful(),
                        t.getUserID(), t.getRoomID()});
    }

    private Transaction mapper(Map<String, Object> map) {
        Transaction t = new Transaction();
        t.setAmountPaid(Double.parseDouble(map.get("amountPaid").toString()));
        t.setDateBookingEnd((Date) map.get("dateBookingEnd"));
        t.setDateBookingStart((Date) map.get("dateBookingStart"));
        t.setRoomID(map.get("roomID").toString());
        t.setRoomPrice(Double.parseDouble(map.get("roomPrice").toString()));
        t.setSuccessful((Boolean) map.get("successful"));
        t.setTransactionID(Integer.parseInt(map.get("transactionID").toString()));
        t.setUserID(map.get("userID").toString());
        return t;
    }


}
