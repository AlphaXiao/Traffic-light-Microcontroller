package luckyhotel.dao;

import luckyhotel.entity.User;
import luckyhotel.util.DbUtil;

import java.util.List;
import java.util.Map;

public class CustomerDao {

    public void save(User user) {
        DbUtil.executeUpdate("insert into tb_user values(?, ?, ?, ?)",
                new Object[]{user.getUserID(), user.getEmail(), user.getPassword(), user.getRole()});
    }

    public User findByEmail(String email) {
        List<Map<String, Object>> list = DbUtil.executeQuery("select * from tb_user t where t.email = ?", new Object[]{email});
        if (list.isEmpty()) {
            return null;
        }
        Map<String, Object> map = list.get(0);
        return mapper(map);
    }

    public void updatePassword(String password, String email) {
        DbUtil.executeUpdate("update tb_user set password = ? where email = ?", new Object[]{password, email});
    }

    private static User mapper(Map<String, Object> map) {
        User t = new User();
        t.setEmail(map.get("email").toString());
        t.setPassword(map.get("password").toString());
        t.setRole(Integer.parseInt(map.get("role").toString()));
        t.setUserID(map.get("userID").toString());
        return t;
    }
}
