package luckyhotel.ui;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import luckyhotel.exception.LoginException;
import luckyhotel.service.CustomerService;
import luckyhotel.util.Session;

public class LoginUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private CustomerService customerService = new CustomerService();
	
	public LoginUI(final int role) {
		if (role == Session.CUSTOMER) {
			this.setTitle("Login as Customer");
		} else {
			this.setTitle("Login as Admin");
		}
		this.setSize(400, 150);
		this.setLayout(new GridLayout(3, 2));
		this.setDefaultCloseOperation(HIDE_ON_CLOSE);
		
		this.add(new JLabel("email"));
		JTextField emailField = new JTextField(20);
		this.add(emailField);
		
		this.add(new JLabel("password"));
		JPasswordField passwordField = new JPasswordField(20);
		this.add(passwordField);
		
		JButton loginButton = new JButton("Login");
		loginButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String email = emailField.getText();
				String password =  new String(passwordField.getPassword());
				try {
					customerService.login(email, password, role);
					if (role == Session.CUSTOMER) {
						new BookCustomerUI().o();
					} else {
						new BookManagerUI().o();
					}
					x();
				} catch (LoginException ex) {
					JOptionPane.showMessageDialog(null, "Login fail. " + ex.getMessage());
				}
			}
		});
		this.add(loginButton);

		JButton returnHomeButton = new JButton("Return Home");
		returnHomeButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new WelcomeUI().o();
				x();
			}
		});
		this.add(returnHomeButton);

	}

	public void o() {
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	public void x() {
		dispose();
	}

}
