package luckyhotel.ui;

import luckyhotel.util.Callback;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class BookRoomUI extends JDialog {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public BookRoomUI(String roomID, Callback callback) {
        this.setSize(400, 300);
        this.setLayout(new GridLayout(4, 2));
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        this.add(new JLabel("roomID"));
        this.add(new JLabel(roomID));

        this.add(new JLabel("Number Of Day"));
        JTextField dayField = new JTextField(20);
        this.add(dayField);

        this.add(new JLabel("Price"));
        JTextField priceField = new JTextField(20);
        this.add(priceField);

        BookRoomUI o = this;

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Map<String, Object> params = new HashMap<>();
                Integer numberOfDay = null;
                try {
                    numberOfDay = Integer.parseInt(dayField.getText());
                    params.put("numberOfDay", numberOfDay);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Number Of Day is invalid");
                    return;
                }
                Double price = null;
                try {
                    price = Double.parseDouble(priceField.getText());
                    params.put("price", price);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Price is invalid");
                    return;
                }
                callback.call(o, params);
            }
        });
        this.add(submitButton);
    }

    public void o() {
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    public void x() {
        dispose();
    }

}
