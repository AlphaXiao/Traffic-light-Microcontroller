package luckyhotel.ui;

import luckyhotel.util.Session;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class WelcomeUI extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public WelcomeUI() {
		this.setTitle("Welcome");
		this.setSize(500, 350);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		
		this.setLayout(new BorderLayout());

		this.add(new JLabel("Welcome lucky hotel", SwingConstants.CENTER), BorderLayout.CENTER);
		
		JPanel soutJPanel = new JPanel();
		this.add(soutJPanel, BorderLayout.SOUTH);
		
		JButton reg = new JButton("Register");
		reg.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new RegisterCustomerUI().o();
				x();
			}
		});
		soutJPanel.add(reg);
		
		JButton loginAsCustomer = new JButton("Login as Customer");
		loginAsCustomer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new LoginUI(Session.CUSTOMER).o();
				x();
			}
		});
		soutJPanel.add(loginAsCustomer);
		
		JButton loginAsAdmin = new JButton("Login as Admin");
		loginAsAdmin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new LoginUI(Session.ADMIN).o();
				x();
			}
		});
		soutJPanel.add(loginAsAdmin);
	}

	public void o() {
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	public void x() {
		dispose();
	}

}
