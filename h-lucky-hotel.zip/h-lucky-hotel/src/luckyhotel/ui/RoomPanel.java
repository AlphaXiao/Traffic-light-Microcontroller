package luckyhotel.ui;

import luckyhotel.entity.Review;
import luckyhotel.entity.Room;
import luckyhotel.exception.TransactionOperationException;
import luckyhotel.service.TransactionService;
import luckyhotel.util.Callback;
import luckyhotel.util.Session;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;

public class RoomPanel extends JPanel {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private TransactionService transactionService = new TransactionService();

    public RoomPanel(Room room, int width, int height) {

        this.setSize(width, height);
        this.setPreferredSize(new Dimension(width, height));
        this.setLayout(new BorderLayout());
        JPanel panel = this;

        JScrollPane sp = new JScrollPane();
        JPanel center = new JPanel();
        center.setLayout(new BorderLayout());
        sp.setViewportView(center);
        panel.add(sp);

        String roomID = room.getRoomID();

        StringBuilder html = new StringBuilder("<html>");
        html.append("<body>");
        html.append("<p>RoomID: ").append(roomID).append("</p>");
        html.append("<p>Description: ").append(room.getDescription()).append("</p>");
        html.append("<p>Amount Of Guest: ").append(room.getAmountOfGuest()).append("</p>");
        html.append("<p>Amount Of Bed: ").append(room.getAmountOfBed()).append("</p>");
        html.append("<p>Price of day: ").append(String.format("%.2f", room.getPrice())).append("</p>");
        html.append("<p>Average Rating: ").append(String.format("%.2f", room.getAverageRating())).append("</p>");
        html.append("<p>&nbsp;</p>");

        List<Review> listOfReview = room.getListOfReview();
        for (Review review : listOfReview) {
            html.append("<p>rating: ").append(String.format("%d", review.getRating())).append("</p>");
            html.append("<p>comment: ").append(review.getComment()).append("</p>");
            html.append("<p>&nbsp;</p>");
        }
        html.append("</body>").append("</html>");
        center.add(new JLabel(html.toString()), BorderLayout.CENTER);

        JButton book = new JButton("Book");
        book.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new BookRoomUI(roomID, new Callback() {
                    @Override
                    public void call(Object o, Map<String, Object> params) {
                        try {
                            Integer numberOfDay = (Integer) params.get("numberOfDay");
                            Double price = (Double) params.get("price");
                            transactionService.book(roomID, Session.getUserID(), numberOfDay, price);
                            JOptionPane.showMessageDialog(null, "Transaction success.");
                            ((BookRoomUI) o).x();
                        } catch (TransactionOperationException ex) {
                            JOptionPane.showMessageDialog(null, "Transaction fail. " + ex.getMessage());
                        }
                    }
                }).o();
            }
        });
        center.add(book, BorderLayout.EAST);
    }

}
