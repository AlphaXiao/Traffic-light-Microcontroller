package luckyhotel.ui;

import luckyhotel.entity.Room;
import luckyhotel.service.RoomService;
import luckyhotel.util.UIUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class BookManagerUI extends JFrame {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private final String[] headers = {"roomID", "Description", "Amount Of Guest", "Amount Of Bed", "Price of day"};

    private RoomService roomService = new RoomService();

    public BookManagerUI() {
        this.setTitle("Book Manager");
        this.setSize(600, 400);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        this.setLayout(new BorderLayout());

        JMenuBar menuBar = new JMenuBar();
        this.setJMenuBar(menuBar);

        JMenu m = new JMenu("Setup");
        menuBar.add(m);

        JMenuItem logoutItem = new JMenuItem("Logout");
        logoutItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                x();
            }
        });
        m.add(logoutItem);

        Object[][] cellData = new Object[0][];
        DefaultTableModel model = new DefaultTableModel(cellData, headers) {
            private static final long serialVersionUID = 1L;

            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        this.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel southJPanel = new JPanel();
        this.add(southJPanel, BorderLayout.SOUTH);

        JButton addRoom = new JButton("Add room");
        addRoom.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AddRoomUI().o();
            }
        });
        southJPanel.add(addRoom);

        JButton updateRoom = new JButton("Update room");
        updateRoom.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRowIndex = table.getSelectedRow();
                if (selectedRowIndex > -1) {
                    String roomID = (String) table.getModel().getValueAt(selectedRowIndex, 0);
                    Room room = roomService.findById(roomID);
                    new UpdateRoomUI(room).o();
                }
            }
        });
        southJPanel.add(updateRoom);

        JButton refreshButton = new JButton("Refresh table");
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refresh(table);
            }
        });
        southJPanel.add(refreshButton);

        refresh(table);
    }

    private void refresh(JTable table) {
        List<Room> all = roomService.findAll();
        List<Object[]> list = new ArrayList<>();
        for (Room room : all) {
            list.add(new Object[]{
                    room.getRoomID(),
                    room.getDescription(),
                    room.getAmountOfGuest(),
                    room.getAmountOfBed(),
                    room.getPrice()
            });
        }
        UIUtil.fillTable(table, list);
    }

    public void o() {
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    public void x() {
        dispose();
    }
}
