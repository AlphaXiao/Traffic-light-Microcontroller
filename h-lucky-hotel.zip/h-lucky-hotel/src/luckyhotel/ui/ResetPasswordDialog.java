package luckyhotel.ui;

import luckyhotel.exception.ResetPasswordException;
import luckyhotel.service.CustomerService;
import luckyhotel.util.Session;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;

public class ResetPasswordDialog extends JDialog {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private CustomerService customerService = new CustomerService();

    public ResetPasswordDialog() {
        this.setTitle("Reset Password");
        this.setSize(300, 200);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        this.setLayout(new GridLayout(3, 2));

        this.add(new JLabel("new password"));
        JPasswordField newpasswordField = new JPasswordField(20);
        this.add(newpasswordField);

        this.add(new JLabel("confirm password"));
        JPasswordField confirmpasswordField = new JPasswordField(20);
        this.add(confirmpasswordField);

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String newpassword = new String(newpasswordField.getPassword());
                String confirmpassword = new String(confirmpasswordField.getPassword());
                if (!Objects.equals(newpassword, confirmpassword)) {
                    JOptionPane.showMessageDialog(null, "new password not equals confirm password");
                    return;
                }
                try {
                    customerService.resetPassword(newpassword, Session.getEmail());
                    JOptionPane.showMessageDialog(null, "reset password success.");
                    x();
                } catch (ResetPasswordException ex) {
                    JOptionPane.showMessageDialog(null, "reset password fail. " + ex.getMessage());
                }
            }
        });
        this.add(submitButton);
    }

    public void o() {
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    public void x() {
        dispose();
    }

}
