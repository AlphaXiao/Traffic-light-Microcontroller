package luckyhotel.ui;

import luckyhotel.entity.Review;
import luckyhotel.exception.ReviewOperationException;
import luckyhotel.service.ReviewService;
import luckyhotel.util.Session;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ReviewUI extends JDialog {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private ReviewService reviewService = new ReviewService();

    public ReviewUI(String roomID) {
        this.setTitle("Submit Review");
        this.setSize(400,300);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        this.setLayout(new GridLayout(4, 2));

        this.add(new JLabel("roomID"));
        this.add(new JLabel(roomID));

        this.add(new JLabel("rating"));
        JTextField ratingField = new JTextField(20);
        this.add(ratingField);

        this.add(new JLabel("Comment"));
        JTextArea commentField = new JTextArea(5, 4);
        this.add(commentField);

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Review review = new Review();
                review.setRoomID(roomID);
                review.setUserID(Session.getUserID());
                String rating = ratingField.getText();
                try {
                    review.setRating(Integer.parseInt(rating));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "rating is invalid");
                    return;
                }
                review.setComment(commentField.getText());
                try {
                    reviewService.save(review);
                    JOptionPane.showMessageDialog(null, "submit review success.");
                    x();
                } catch (ReviewOperationException ex) {
                    JOptionPane.showMessageDialog(null, "submit review fail. " + ex.getMessage());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "submit review fail.");
                }
            }
        });
        this.add(submitButton);
    }

    public void o() {
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    public void x() {
        dispose();
    }

}
