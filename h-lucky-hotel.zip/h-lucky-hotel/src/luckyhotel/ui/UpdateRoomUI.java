package luckyhotel.ui;

import luckyhotel.entity.Room;
import luckyhotel.exception.RoomOperationException;
import luckyhotel.service.RoomService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UpdateRoomUI extends JDialog {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private RoomService roomService = new RoomService();

    public UpdateRoomUI(Room room) {
        this.setTitle("Update room");
        this.setSize(500, 300);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        this.setLayout(new GridLayout(6, 2));

        String roomID = room.getRoomID();

        this.add(new JLabel("roomID"));
        this.add(new JLabel(roomID));

        this.add(new JLabel("Description"));
        JTextArea tfDescription = new JTextArea(5, 10);
        tfDescription.setText(room.getDescription());
        this.add(tfDescription);

        this.add(new JLabel("Amount Of Guest"));
        JTextField tfAmountOfGuest = new JTextField(20);
        tfAmountOfGuest.setText(room.getAmountOfGuest() + "");
        this.add(tfAmountOfGuest);

        this.add(new JLabel("Amount Of Bed"));
        JComboBox<String> cbAmountOfBed = new JComboBox<>();
        cbAmountOfBed.addItem("Single");
        cbAmountOfBed.addItem("Twin");
        cbAmountOfBed.setSelectedIndex(room.getAmountOfBed() - 1);
        this.add(cbAmountOfBed);

        this.add(new JLabel("Price of day"));
        JTextField tfPriceOfDay = new JTextField(20);
        tfPriceOfDay.setText(String.format("%.2f", room.getPrice()));
        this.add(tfPriceOfDay);

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Room room = new Room();
                try {
                    room.setPrice(Double.parseDouble(tfPriceOfDay.getText()));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "price of day is invalid.");
                    return ;
                }
                room.setDescription(tfDescription.getText());
                room.setAverageRating(0.0);
                try {
                    room.setAmountOfGuest(Integer.parseInt(tfAmountOfGuest.getText()));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "amount of guest is invalid.");
                    return ;
                }
                int selectedIndex = cbAmountOfBed.getSelectedIndex();
                room.setAmountOfBed(selectedIndex + 1);
                room.setRoomID(roomID);
                try {
                    roomService.update(room);
                    JOptionPane.showMessageDialog(null, "Room update success.");
                    x();
                } catch (RoomOperationException ex) {
                    JOptionPane.showMessageDialog(null, "Room update fail. " + ex.getMessage());
                } catch (Exception e1) {
                    JOptionPane.showMessageDialog(null, "Room update fail. ");
                }
            }
        });
        this.add(submitButton);

    }

    public void o() {
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    public void x() {
        dispose();
    }
}
