package luckyhotel.ui;

import luckyhotel.entity.Room;
import luckyhotel.exception.RoomOperationException;
import luckyhotel.service.RoomService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddRoomUI extends JDialog {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private RoomService roomService = new RoomService();

    public AddRoomUI() {
        this.setTitle("Add room");
        this.setSize(500, 300);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        this.setLayout(new GridLayout(6, 2));

        this.add(new JLabel("roomID"));
        JTextField tfRoomID = new JTextField(20);
        this.add(tfRoomID);

        this.add(new JLabel("Description"));
        JTextArea tfDescription = new JTextArea(5, 10);
        this.add(tfDescription);

        this.add(new JLabel("Amount Of Guest"));
        JTextField tfAmountOfGuest = new JTextField(20);
        this.add(tfAmountOfGuest);

        this.add(new JLabel("Amount Of Bed"));
        JComboBox<String> cbAmountOfBed = new JComboBox<>();
        cbAmountOfBed.addItem("Single");
        cbAmountOfBed.addItem("Twin");
        this.add(cbAmountOfBed);

        this.add(new JLabel("Price of day"));
        JTextField tfPriceOfDay = new JTextField(20);
        this.add(tfPriceOfDay);

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Room room = new Room();
                try {
                    room.setPrice(Double.parseDouble(tfPriceOfDay.getText()));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "price of day is invalid.");
                    return ;
                }
                room.setDescription(tfDescription.getText());
                room.setAverageRating(0.0);
                try {
                    room.setAmountOfGuest(Integer.parseInt(tfAmountOfGuest.getText()));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "amount of guest is invalid.");
                    return ;
                }
                int selectedIndex = cbAmountOfBed.getSelectedIndex();
                room.setAmountOfBed(selectedIndex + 1);
                room.setRoomID(tfRoomID.getText());
                try {
                    roomService.save(room);
                    JOptionPane.showMessageDialog(null, "Room save success.");
                    x();
                } catch (RoomOperationException ex) {
                    JOptionPane.showMessageDialog(null, "Room save fail. " + ex.getMessage());
                } catch (Exception e1) {
                    JOptionPane.showMessageDialog(null, "Room save fail. ");
                }
            }
        });
        this.add(submitButton);
    }


    public void o() {
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    public void x() {
        dispose();
    }

}
