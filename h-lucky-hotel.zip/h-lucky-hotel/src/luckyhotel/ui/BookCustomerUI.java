package luckyhotel.ui;

import luckyhotel.entity.Room;
import luckyhotel.entity.RoomQuery;
import luckyhotel.entity.Transaction;
import luckyhotel.service.RoomService;
import luckyhotel.service.TransactionService;
import luckyhotel.util.Session;
import luckyhotel.util.UIUtil;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class BookCustomerUI extends JFrame {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private RoomService roomService = new RoomService();

    private TransactionService transactionService = new TransactionService();

    private final String[] headers = {"transactionID", "dateBookingStart", "dateBookingEnd", "amountPaid", "roomPrice", "successful", "roomID"};
    private DefaultTableModel model = new DefaultTableModel(new Object[0][], headers) {
        private static final long serialVersionUID = 1L;

        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    public BookCustomerUI() {
        this.setTitle("Book Room");
        this.setSize(1100, 650);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        this.setLayout(new BorderLayout());

        JMenuBar menuBar = new JMenuBar();
        this.setJMenuBar(menuBar);

        JMenu m = new JMenu("Setup");
        menuBar.add(m);

        JMenuItem updatePasswordItem = new JMenuItem("Update password");
        updatePasswordItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new UpdatePasswordDialog().o();
            }
        });
        m.add(updatePasswordItem);

        JMenuItem resetPasswordItem = new JMenuItem("Reset password");
        resetPasswordItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ResetPasswordDialog().o();
            }
        });
        m.add(resetPasswordItem);

        JMenuItem logoutItem = new JMenuItem("Logout");
        logoutItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                x();
            }
        });
        m.add(logoutItem);

        JTabbedPane tabbedPane = new JTabbedPane();
        this.add(tabbedPane, BorderLayout.CENTER);

        JPanel bookRoom = new JPanel();
        bookRoom.setLayout(new BorderLayout());
        tabbedPane.addTab("Book room", bookRoom);

        JPanel myTransaction = new JPanel();
        myTransaction.setLayout(new BorderLayout());
        tabbedPane.addTab("My Transaction", myTransaction);

        JPanel bookRoomCenterPanel = new JPanel();
        bookRoom.add(new JScrollPane(bookRoomCenterPanel), BorderLayout.CENTER);

        JPanel bookRoomNorthJPanel = new JPanel();
        bookRoom.add(bookRoomNorthJPanel, BorderLayout.NORTH);

        bookRoomNorthJPanel.add(new JLabel("price"));
        JTextField tfMinPrice = new JTextField(5);
        bookRoomNorthJPanel.add(tfMinPrice);
        bookRoomNorthJPanel.add(new JLabel("-"));
        JTextField tfManPrice = new JTextField(5);
        bookRoomNorthJPanel.add(tfManPrice);
        bookRoomNorthJPanel.add(new JLabel("rating"));
        JTextField tfAvgRating = new JTextField(5);
        bookRoomNorthJPanel.add(tfAvgRating);
        bookRoomNorthJPanel.add(new JLabel("amount of guest"));
        JTextField tfGuest = new JTextField(5);
        bookRoomNorthJPanel.add(tfGuest);
        bookRoomNorthJPanel.add(new JLabel("amount of bed"));
        JTextField tfBed = new JTextField(5);
        bookRoomNorthJPanel.add(tfBed);

        bookRoomNorthJPanel.add(new JLabel("sort"));
        JComboBox<String> sortField = new JComboBox<>();
        sortField.addItem(null);
        sortField.addItem("price");
        sortField.addItem("amountOfGuest");
        sortField.addItem("amountOfBed");
        sortField.addItem("averageRating");
        bookRoomNorthJPanel.add(sortField);

        JComboBox<String> ascField = new JComboBox<>();
        ascField.addItem(null);
        ascField.addItem("Asc");
        ascField.addItem("Desc");
        bookRoomNorthJPanel.add(ascField);

        JButton searchButton = new JButton("Search");
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                RoomQuery roomQuery = new RoomQuery();
                String bed = tfBed.getText();
                if (bed != null && !"".equals(bed)) {
                    try {
                        roomQuery.setAmountOfBed(Integer.parseInt(bed));
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "amount of bed is invalid");
                        return;
                    }
                }
                String guest = tfGuest.getText();
                if (guest != null && !"".equals(guest)) {
                    try {
                        roomQuery.setAmountOfGuest(Integer.parseInt(guest));
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "amount of guest is invalid");
                        return;
                    }
                }
                String minPrice = tfMinPrice.getText();
                if (minPrice != null && !"".equals(minPrice)) {
                    try {
                        roomQuery.setMinPrice(Double.parseDouble(minPrice));
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "min price is invalid");
                        return;
                    }
                }
                String manPrice = tfManPrice.getText();
                if (manPrice != null && !"".equals(manPrice)) {
                    try {
                        roomQuery.setMaxPrice(Double.parseDouble(manPrice));
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "man price is invalid");
                        return;
                    }
                }
                String avgRating = tfAvgRating.getText();
                if (avgRating != null && !"".equals(avgRating)) {
                    try {
                        roomQuery.setRating(Double.parseDouble(avgRating));
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "rating is invalid");
                        return;
                    }
                }
                String sort = (String) sortField.getSelectedItem();
                roomQuery.setSortField(sort);
                String asc = (String) ascField.getSelectedItem();
                roomQuery.setAsc(asc);
                refreshBookRoom(bookRoomCenterPanel, roomService.findNotBookRoom(roomQuery));
            }
        });
        bookRoomNorthJPanel.add(searchButton);

        // my transaction center
        JTable table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        myTransaction.add(new JScrollPane(table), BorderLayout.CENTER);

        // my transaction south
        JPanel myTransactionSouthPanel = new JPanel();
        myTransaction.add(myTransactionSouthPanel, BorderLayout.SOUTH);
        JButton review = new JButton("Submit Review");
        review.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRowIndex = table.getSelectedRow();
                if (selectedRowIndex > -1) {
                    String roomID = (String) table.getModel().getValueAt(selectedRowIndex, headers.length - 1);
                    new ReviewUI(roomID).o();
                }
            }
        });
        myTransactionSouthPanel.add(review);

        tabbedPane.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                JTabbedPane pane = (JTabbedPane) e.getSource();
                int selectedIndex = pane.getSelectedIndex();
                if (selectedIndex == 0) {
                    RoomQuery roomQuery = new RoomQuery();
                    String bed = tfBed.getText();
                    if (bed != null && !"".equals(bed)) {
                        try {
                            roomQuery.setAmountOfBed(Integer.parseInt(bed));
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "amount of bed is invalid");
                            return;
                        }
                    }
                    String guest = tfGuest.getText();
                    if (guest != null && !"".equals(guest)) {
                        try {
                            roomQuery.setAmountOfGuest(Integer.parseInt(guest));
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "amount of guest is invalid");
                            return;
                        }
                    }
                    String minPrice = tfMinPrice.getText();
                    if (minPrice != null && !"".equals(minPrice)) {
                        try {
                            roomQuery.setMinPrice(Double.parseDouble(minPrice));
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "min price is invalid");
                            return;
                        }
                    }
                    String manPrice = tfManPrice.getText();
                    if (manPrice != null && !"".equals(manPrice)) {
                        try {
                            roomQuery.setMaxPrice(Double.parseDouble(manPrice));
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "man price is invalid");
                            return;
                        }
                    }
                    String avgRating = tfAvgRating.getText();
                    if (avgRating != null && !"".equals(avgRating)) {
                        try {
                            roomQuery.setRating(Double.parseDouble(avgRating));
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "rating is invalid");
                            return;
                        }
                    }
                    String sort = (String) sortField.getSelectedItem();
                    roomQuery.setSortField(sort);
                    String asc = (String) ascField.getSelectedItem();
                    roomQuery.setAsc(asc);
                    refreshBookRoom(bookRoomCenterPanel, roomService.findNotBookRoom(roomQuery));
                } else if (selectedIndex == 1) {
                    refreshMyTransaction(table, transactionService.findByUserID(Session.getUserID()));
                }
            }
        });


        refreshBookRoom(bookRoomCenterPanel, roomService.findNotBookRoom(new RoomQuery()));
    }

    private void refreshBookRoom(JPanel panel, List<Room> list) {
        panel.removeAll();
        panel.repaint();
        if (list.size() > 0) {
            panel.setLayout(new GridLayout(list.size(), 1));
            for (Room room : list) {
                panel.add(new RoomPanel(room, 600 - 150, 150));
            }
        }
        panel.revalidate();
    }

    private void refreshMyTransaction(JTable table, List<Transaction> all) {
        List<Object[]> list = new ArrayList<>();
        for (Transaction t : all) {
            list.add(new Object[]{
                    t.getTransactionID() + "",
                    new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(t.getDateBookingStart()),
                    new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(t.getDateBookingEnd()),
                    String.format("%.2f", t.getAmountPaid()),
                    String.format("%.2f", t.getRoomPrice()),
                    t.getSuccessful().toString(),
                    t.getRoomID()
            });
        }
        UIUtil.fillTable(table, list);
    }

    public void o() {
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    public void x() {
        dispose();
    }

}
