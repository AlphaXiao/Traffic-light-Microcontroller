package luckyhotel.service;

import luckyhotel.dao.ReviewDao;
import luckyhotel.dao.RoomDao;
import luckyhotel.entity.Review;
import luckyhotel.exception.ReviewOperationException;

import java.util.List;

public class ReviewService {

    private ReviewDao reviewDao = new ReviewDao();
    private RoomDao roomDao = new RoomDao();

    public void save(Review review) {
        Integer rating = review.getRating();
        if (rating == null) {
            throw new ReviewOperationException("rating is invalid");
        }
        String userID = review.getUserID();
        if (userID == null) {
            throw new ReviewOperationException("userID is invalid");
        }
        String roomID = review.getRoomID();
        if (roomID == null) {
            throw new ReviewOperationException("roomID is invalid");
        }
        reviewDao.save(review);

        List<Review> reviews = reviewDao.findByRoomID(roomID);
        double sum = 0.0;
        for (Review r : reviews) {
            sum += r.getRating();
        }
        roomDao.updateAverageRating(roomID, sum / reviews.size());
    }
}
