package luckyhotel.service;

import luckyhotel.dao.RoomDao;
import luckyhotel.dao.TransactionDao;
import luckyhotel.entity.Room;
import luckyhotel.entity.Transaction;
import luckyhotel.exception.TransactionOperationException;
import luckyhotel.util.DbUtil;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class TransactionService {

    private TransactionDao transactionDao = new TransactionDao();

    private RoomDao roomDao = new RoomDao();

    public List<Transaction> findByUserID(String userID) {
        return transactionDao.findByUserID(userID);
    }

    public void book(String roomID, String userID, Integer numberOfDay, Double price) {
        if (numberOfDay == null || numberOfDay < 1) {
            throw new TransactionOperationException("numberOfDay is invalid");
        }
        if (price == null) {
            throw new TransactionOperationException("price is invalid");
        }
        Room room = roomDao.findByRoomID(roomID);
        if (room == null) {
            throw new TransactionOperationException("room not found");
        }
        double v = room.getPrice() * numberOfDay;
        if (BigDecimal.valueOf(v).compareTo(BigDecimal.valueOf(price)) != 0) {
            throw new TransactionOperationException("pay amount not correct.");
        }

        Date dateBookingStart = new Date();
        Date dateBookingEnd = DbUtil.addDatetime(dateBookingStart, Calendar.DAY_OF_MONTH, numberOfDay);
        Transaction t = new Transaction();
        t.setUserID(userID);
        t.setRoomID(roomID);
        t.setRoomPrice(room.getPrice());
        t.setDateBookingStart(dateBookingStart);
        t.setDateBookingEnd(dateBookingEnd);
        t.setAmountPaid(v);
        t.setSuccessful(true);

        transactionDao.save(t);
    }

}
