package luckyhotel.service;

import luckyhotel.dao.ReviewDao;
import luckyhotel.dao.RoomDao;
import luckyhotel.dao.TransactionDao;
import luckyhotel.entity.Room;
import luckyhotel.entity.RoomQuery;
import luckyhotel.entity.Transaction;
import luckyhotel.exception.RoomOperationException;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RoomService {

    private RoomDao roomDao = new RoomDao();

    private ReviewDao reviewDao = new ReviewDao();

    private TransactionDao transactionDao = new TransactionDao();

    public List<Room> findAll() {
        List<Room> all = roomDao.findAll();
        for (Room room : all) {
            room.setListOfReview(reviewDao.findByRoomID(room.getRoomID()));
        }
        return all;
    }

    public List<Room> findNotBookRoom(RoomQuery roomQuery) {
        List<Transaction> all = transactionDao.findByGtEndDate(new Date());
        Set<String> roomIDSet = new HashSet<>();
        for (Transaction transaction : all) {
            roomIDSet.add(transaction.getRoomID());
        }
        roomQuery.setNotInRoomIDSet(roomIDSet);
        List<Room> rooms = roomDao.findByRoomQuery(roomQuery);
        for (Room room : rooms) {
            room.setListOfReview(reviewDao.findByRoomID(room.getRoomID()));
        }
        return rooms;
    }

    public void save(Room room) {
        if (room == null) {
            throw new RoomOperationException("room is invalid");
        }
        Double price = room.getPrice();
        if (price == null || price < 0.0) {
            throw new RoomOperationException("price is invalid");
        }
        Integer amountOfBed = room.getAmountOfBed();
        if (amountOfBed == null || amountOfBed <= 0) {
            throw new RoomOperationException("amount of bed is invalid.");
        }
        Integer amountOfGuest = room.getAmountOfGuest();
        if (amountOfGuest == null) {
            throw new RoomOperationException("amount of guest is invalid.");
        }
        String description = room.getDescription();
        if (description == null || description.length() > 90) {
            throw new RoomOperationException("description is invalid.");
        }
        String roomID = room.getRoomID();
        if (roomID == null || "".equals(roomID.trim())) {
            throw new RoomOperationException("roomID is invalid.");
        }
        if (roomDao.findByRoomID(roomID) != null) {
            throw new RoomOperationException("room has exists.");
        }
        roomDao.save(room);
    }


    public void update(Room room) {
        if (room == null) {
            throw new RoomOperationException("room is invalid");
        }
        Double price = room.getPrice();
        if (price == null || price < 0.0) {
            throw new RoomOperationException("price is invalid");
        }
        Integer amountOfBed = room.getAmountOfBed();
        if (amountOfBed == null || amountOfBed <= 0) {
            throw new RoomOperationException("amount of bed is invalid.");
        }
        Integer amountOfGuest = room.getAmountOfGuest();
        if (amountOfGuest == null) {
            throw new RoomOperationException("amount of guest is invalid.");
        }
        String description = room.getDescription();
        if (description == null || description.length() > 90) {
            throw new RoomOperationException("description is invalid.");
        }
        String roomID = room.getRoomID();
        if (roomID == null || "".equals(roomID.trim())) {
            throw new RoomOperationException("roomID is invalid.");
        }
        Room byRoomID = roomDao.findByRoomID(roomID);
        if (byRoomID == null) {
            throw new RoomOperationException("room not found.");
        }
        byRoomID.setPrice(price);
        byRoomID.setAmountOfBed(amountOfBed);
        byRoomID.setAmountOfGuest(amountOfGuest);
        byRoomID.setDescription(description);
        roomDao.update(byRoomID);
    }

    public Room findById(String roomID) {
        Room room = roomDao.findByRoomID(roomID);
        if (room != null) {
            room.setListOfReview(reviewDao.findByRoomID(roomID));
        }
        return room;
    }




}
