package luckyhotel.service;

import java.util.Objects;
import java.util.UUID;
import java.util.regex.Pattern;

import luckyhotel.dao.CustomerDao;
import luckyhotel.entity.User;
import luckyhotel.exception.LoginException;
import luckyhotel.exception.RegisterException;
import luckyhotel.exception.ResetPasswordException;
import luckyhotel.exception.UpdatePasswordException;
import luckyhotel.util.Session;

public class CustomerService {
	
	private CustomerDao customerDao = new CustomerDao();
	
	private static final String EMAIL_REGEX = "^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$";
	
	public void register(String email, String password, Integer role) {
		if (!Pattern.matches(EMAIL_REGEX, email)) {
			throw new RegisterException("email pattern is invalid.");
		}
		if (password == null || "".equals(password.trim()) || password.length() > 20) {
			throw new RegisterException("password is invalid.");
		}
		
		User user = findByEmail(email);
		if (user != null) {
			throw new RegisterException("email exists.");
		}
		user = new User();
		user.setUserID(UUID.randomUUID().toString());
		user.setEmail(email);
		user.setPassword(password);
		user.setRole(role);
		customerDao.save(user);
	}
	
	private User findByEmail(String email) {
		User user = customerDao.findByEmail(email);
		return user;
	}

	public void login(String email, String password, Integer role) {
		User user = findByEmail(email);
		if (user == null) {
			throw new LoginException("user not found.");
		}
		String userPassword = user.getPassword();
		Integer userRole = user.getRole();
		if (!userPassword.equals(password)) {
			throw new LoginException("password not correct.");
		}
		if (!userRole.equals(role)) {
			throw new LoginException("role not correct.");
		}
		Session.setUser(user.getUserID(), email, role);
	}

	public void updatePassword(String oldpassword, String newpassword, String email) {
		User user = findByEmail(email);
		if (user == null) {
			throw new UpdatePasswordException("user not found.");
		}
		String password = user.getPassword();
		if (!Objects.equals(oldpassword, password)) {
			throw new UpdatePasswordException("old password not correct.");
		}
		if (newpassword == null || "".equals(newpassword.trim()) || newpassword.length() > 20) {
			throw new RegisterException("new password is invalid.");
		}
		customerDao.updatePassword(newpassword, email);
	}

	public void resetPassword(String newpassword, String email) {
		User user = findByEmail(email);
		if (user == null) {
			throw new ResetPasswordException("user not found.");
		}
		if (newpassword == null || "".equals(newpassword.trim()) || newpassword.length() > 20) {
			throw new RegisterException("new password is invalid.");
		}
		customerDao.updatePassword(newpassword, email);
	}
}
